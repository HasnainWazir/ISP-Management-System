# ISP Management System

A full-stack ISP Management System built with Flask (Python) + PostgreSQL backend and plain HTML/CSS/JS frontend.

---

## 📁 Project Structure

```
isp_management/
├── backend/
│   ├── app.py              ← Flask entry point
│   ├── database.py         ← DB connection config
│   ├── requirements.txt
│   └── routes/
│       ├── auth.py
│       ├── customers.py
│       ├── packages.py
│       ├── subscriptions.py
│       ├── bills.py
│       ├── payments.py
│       ├── complaints.py
│       ├── technicians.py
│       ├── assignments.py
│       └── reports.py
└── frontend/
    ├── index.html          ← Login page
    ├── dashboard.html
    ├── customers.html
    ├── packages.html
    ├── subscriptions.html
    ├── bills.html
    ├── payments.html
    ├── complaints.html
    ├── technicians.html
    ├── reports.html
    ├── css/
    │   └── style.css
    └── js/
        └── api.js
```

---

## ⚙️ Setup Instructions

### Step 1 — Database Setup

1. Make sure **PostgreSQL** is installed and running.
2. Open pgAdmin or psql and run the **Table_Creation.sql** file to create all tables.
3. Restore sample data from **Sample_Data.sql** (it's a pg_dump file):
   ```
   pg_restore -U postgres -d postgres Sample_Data.sql
   ```
   OR manually insert your own data after setup.

---

### Step 2 — Backend Setup

1. Open a terminal and navigate to the `backend/` folder:
   ```
   cd isp_management/backend
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. **Edit `database.py`** and update your PostgreSQL credentials:
   ```python
   DB_CONFIG = {
       "host": "localhost",
       "port": 5432,
       "database": "postgres",   # your database name
       "user": "postgres",       # your username
       "password": "your_password_here"  # ← CHANGE THIS
   }
   ```

4. Start the Flask server:
   ```
   python app.py
   ```

   You should see:
   ```
    * Running on http://127.0.0.1:5000
   ```

---

### Step 3 — Frontend Setup

No build tools needed! Just open the frontend files in a browser.

**Option A — Double-click (simplest):**
- Open `frontend/index.html` directly in your browser.

**Option B — Local server (recommended, avoids CORS issues with file://):**
```
cd isp_management/frontend
python -m http.server 8080
```
Then visit: **http://localhost:8080**

---

## 🔐 Default Login Credentials

After restoring sample data, try:

| Username   | Password    | Role     |
|------------|-------------|----------|
| admin123   | adminpass   | Admin    |
| staff01    | staffpass   | Staff    |

*(Or check the Users table in your database for existing accounts.)*

---

## 🌐 API Endpoints

### Auth
| Method | Endpoint   | Description       |
|--------|-----------|-------------------|
| POST   | /login    | Login validation  |

### Customers
| Method | Endpoint              | Description             |
|--------|-----------------------|-------------------------|
| GET    | /customers            | List all / search       |
| POST   | /customers            | Add customer            |
| GET    | /customers/{id}       | Get single customer     |
| PUT    | /customers/{id}       | Update customer         |
| DELETE | /customers/{id}       | Delete customer         |
| GET    | /areas                | List all areas          |
| POST   | /areas                | Add new area            |

### Packages
| Method | Endpoint           | Description      |
|--------|--------------------|------------------|
| GET    | /packages          | List packages    |
| POST   | /packages          | Add package      |
| PUT    | /packages/{id}     | Update package   |
| DELETE | /packages/{id}     | Delete package   |

### Subscriptions
| Method | Endpoint                          | Description                |
|--------|-----------------------------------|----------------------------|
| GET    | /subscriptions                    | List all subscriptions     |
| POST   | /subscriptions                    | Create subscription        |
| GET    | /subscriptions/customer/{id}      | Customer's subscriptions   |

### Bills
| Method | Endpoint              | Description             |
|--------|-----------------------|-------------------------|
| GET    | /bills                | All bills               |
| GET    | /bills/unpaid         | Unpaid/overdue bills    |
| GET    | /bills/customer/{id}  | Bills for a customer    |
| POST   | /bills/generate       | Generate from sub       |
| POST   | /bills/mark-overdue   | Mark overdue bills      |

### Payments
| Method | Endpoint              | Description           |
|--------|-----------------------|-----------------------|
| GET    | /payments             | All payments          |
| POST   | /payments             | Record payment        |
| GET    | /payments/bill/{id}   | Payments for a bill   |

### Complaints
| Method | Endpoint                       | Description             |
|--------|--------------------------------|-------------------------|
| GET    | /complaints                    | All complaints          |
| POST   | /complaints                    | Register complaint      |
| PUT    | /complaints/{id}               | Update status           |
| POST   | /complaints/close-resolved     | Close resolved ones     |

### Technicians
| Method | Endpoint              | Description           |
|--------|-----------------------|-----------------------|
| GET    | /technicians          | List technicians      |
| POST   | /technicians          | Add technician        |
| DELETE | /technicians/{id}     | Delete technician     |

### Assignments
| Method | Endpoint                          | Description               |
|--------|-----------------------------------|---------------------------|
| GET    | /assignments                      | All assignments           |
| POST   | /assignments                      | Assign technician         |
| GET    | /assignments/technician/{id}      | Technician's assignments  |

### Reports
| Method | Endpoint                      | Description                  |
|--------|-------------------------------|------------------------------|
| GET    | /reports/dashboard            | Summary stats                |
| GET    | /reports/revenue              | Revenue & monthly breakdown  |
| GET    | /reports/unpaid-bills         | Unpaid bill summary          |
| GET    | /reports/complaints-summary   | Complaint analytics          |
| GET    | /reports/customers-per-area   | Area distribution            |
| GET    | /reports/packages             | Package analytics            |
| GET    | /reports/bills-summary        | Per-customer bill summary    |

---

## 🛠️ Troubleshooting

| Problem | Solution |
|---------|---------|
| CORS error in browser | Run frontend with `python -m http.server` instead of file:// |
| Connection refused | Make sure Flask is running on port 5000 |
| DB auth error | Check password in `database.py` |
| Table not found | Run `Table_Creation.sql` first |

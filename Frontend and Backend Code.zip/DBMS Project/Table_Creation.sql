-- ISP Management System Database Schema for SQLite

CREATE TABLE IF NOT EXISTS Users (
    username TEXT PRIMARY KEY,
    passwords TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Areas (
    area_id INTEGER PRIMARY KEY AUTOINCREMENT,
    area_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    username TEXT UNIQUE,
    phone_number TEXT,
    address TEXT,
    area_id INTEGER,
    FOREIGN KEY (area_id) REFERENCES Areas(area_id)
);

CREATE TABLE IF NOT EXISTS Packages (
    package_id INTEGER PRIMARY KEY AUTOINCREMENT,
    internet_speed TEXT,
    price REAL NOT NULL,
    data_limit TEXT
);

CREATE TABLE IF NOT EXISTS Subscriptions (
    subscription_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    package_id INTEGER NOT NULL,
    start_date TEXT,
    end_date TEXT,
    status TEXT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (package_id) REFERENCES Packages(package_id)
);

CREATE TABLE IF NOT EXISTS Bills (
    bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    subscription_id INTEGER,
    amount REAL NOT NULL,
    due_date TEXT,
    status TEXT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (subscription_id) REFERENCES Subscriptions(subscription_id)
);

CREATE TABLE IF NOT EXISTS Payments (
    payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    payment_date TEXT,
    FOREIGN KEY (bill_id) REFERENCES Bills(bill_id)
);

CREATE TABLE IF NOT EXISTS Complaints (
    complaint_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    description TEXT,
    status TEXT,
    created_at TEXT,
    resolved_at TEXT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE IF NOT EXISTS Technicians (
    technician_id INTEGER PRIMARY KEY AUTOINCREMENT,
    technician_name TEXT NOT NULL,
    username TEXT UNIQUE,
    phone_number TEXT,
    specialization TEXT
);

CREATE TABLE IF NOT EXISTS Assignments (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    complaint_id INTEGER NOT NULL,
    technician_id INTEGER NOT NULL,
    assigned_date TEXT,
    status TEXT,
    FOREIGN KEY (complaint_id) REFERENCES Complaints(complaint_id),
    FOREIGN KEY (technician_id) REFERENCES Technicians(technician_id)
);

-- Insert default users
INSERT OR IGNORE INTO Users (username, passwords, role) VALUES ('admin123', 'adminpass', 'Admin');
INSERT OR IGNORE INTO Users (username, passwords, role) VALUES ('staff01', 'staffpass', 'Staff');

-- Insert sample areas
INSERT OR IGNORE INTO Areas (area_name) VALUES ('Downtown');
INSERT OR IGNORE INTO Areas (area_name) VALUES ('Suburb A');
INSERT OR IGNORE INTO Areas (area_name) VALUES ('Suburb B');

-- Insert sample packages
INSERT OR IGNORE INTO Packages (internet_speed, price, data_limit) VALUES ('50 Mbps', 29.99, 'Unlimited');
INSERT OR IGNORE INTO Packages (internet_speed, price, data_limit) VALUES ('100 Mbps', 49.99, 'Unlimited');
INSERT OR IGNORE INTO Packages (internet_speed, price, data_limit) VALUES ('200 Mbps', 69.99, 'Unlimited');
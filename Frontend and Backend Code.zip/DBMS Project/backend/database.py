import psycopg2
import psycopg2.extras

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "DBMS Project",
    "user": "postgres",
    "password": "asfi"  # Change this to your PostgreSQL password
}

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def execute_query(query, params=None, fetch=None):
    """
    fetch: 'one', 'all', or None (for INSERT/UPDATE/DELETE)
    Returns rows as dicts, or lastrowid, or None.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(query, params)
        if fetch == 'all':
            result = [dict(row) for row in cur.fetchall()]
        elif fetch == 'one':
            row = cur.fetchone()
            result = dict(row) if row else None
        else:
            result = None
        conn.commit()
        return result
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()

from flask import Flask
from flask_cors import CORS

from routes.auth import auth_bp
from routes.customers import customers_bp
from routes.packages import packages_bp
from routes.subscriptions import subscriptions_bp
from routes.bills import bills_bp
from routes.payments import payments_bp
from routes.complaints import complaints_bp
from routes.technicians import technicians_bp
from routes.assignments import assignments_bp
from routes.reports import reports_bp

app = Flask(__name__)
CORS(app)

# Register all blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(customers_bp)
app.register_blueprint(packages_bp)
app.register_blueprint(subscriptions_bp)
app.register_blueprint(bills_bp)
app.register_blueprint(payments_bp)
app.register_blueprint(complaints_bp)
app.register_blueprint(technicians_bp)
app.register_blueprint(assignments_bp)
app.register_blueprint(reports_bp)

@app.errorhandler(Exception)
def handle_error(e):
    return {'error': str(e)}, 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)

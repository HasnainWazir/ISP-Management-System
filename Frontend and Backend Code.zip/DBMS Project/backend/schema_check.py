import psycopg2

conf = {
    'host': 'localhost',
    'port': 5432,
    'database': 'DBMS Project',
    'user': 'postgres',
    'password': 'asfi'
}
conn = psycopg2.connect(**conf)
cur = conn.cursor()
for table in ['Customers', 'Technicians']:
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_name=%s", (table.lower(),))
    cols = [r[0] for r in cur.fetchall()]
    print(table, cols)
conn.close()

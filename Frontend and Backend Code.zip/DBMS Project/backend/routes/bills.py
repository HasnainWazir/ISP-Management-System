from flask import Blueprint, request, jsonify
from database import execute_query

bills_bp = Blueprint('bills', __name__)

@bills_bp.route('/bills', methods=['GET'])
def get_bills():
    rows = execute_query(
        """SELECT b.bill_id, c.customer_name, b.billed_amount, b.due_date, b.status, b.customer_id
           FROM Bills b JOIN Customers c ON b.customer_id = c.customer_id
           ORDER BY b.bill_id DESC""",
        fetch='all'
    )
    return jsonify(rows)

@bills_bp.route('/bills/unpaid', methods=['GET'])
def get_unpaid_bills():
    rows = execute_query(
        """SELECT b.bill_id, c.customer_name, c.phone_number, b.billed_amount,
                  b.due_date, b.status, CURRENT_DATE - b.due_date AS days_overdue
           FROM Bills b JOIN Customers c ON b.customer_id = c.customer_id
           WHERE b.status IN ('Unpaid', 'Overdue')
           ORDER BY b.due_date ASC""",
        fetch='all'
    )
    return jsonify(rows)

@bills_bp.route('/bills/customer/<int:cid>', methods=['GET'])
def get_customer_bills(cid):
    rows = execute_query(
        """SELECT b.bill_id, b.billed_amount, b.due_date, b.status
           FROM Bills b WHERE b.customer_id = %s ORDER BY b.bill_id DESC""",
        (cid,), fetch='all'
    )
    return jsonify(rows)

@bills_bp.route('/bills/generate', methods=['POST'])
def generate_bill():
    data = request.get_json()
    subscription_id = data.get('subscription_id')
    execute_query(
        """INSERT INTO Bills (customer_id, billed_amount, due_date, status)
           SELECT s.customer_id, p.price, CURRENT_DATE + INTERVAL '30 days', 'Unpaid'
           FROM Subscriptions s JOIN Packages p ON s.package_id = p.package_id
           WHERE s.subscription_id = %s""",
        (subscription_id,)
    )
    return jsonify({'success': True, 'message': 'Bill generated'}), 201

@bills_bp.route('/bills/mark-overdue', methods=['POST'])
def mark_overdue():
    execute_query(
        "UPDATE Bills SET status = 'Overdue' WHERE status = 'Unpaid' AND due_date < CURRENT_DATE"
    )
    return jsonify({'success': True, 'message': 'Overdue bills updated'})

@bills_bp.route('/bills/<int:bid>/pay', methods=['POST'])
def pay_bill(bid):
    execute_query(
        "UPDATE Bills SET status = 'Paid' WHERE bill_id = %s",
        (bid,)
    )
    return jsonify({'success': True, 'message': 'Bill paid successfully'}), 200

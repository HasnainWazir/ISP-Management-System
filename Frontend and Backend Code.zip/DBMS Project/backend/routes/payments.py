from flask import Blueprint, request, jsonify
from database import execute_query

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/payments', methods=['GET'])
def get_payments():
    rows = execute_query(
        """SELECT py.payment_id, py.bill_id, c.customer_name, py.paid_amount,
                  py.payment_date, py.method, py.status
           FROM Payments py
           JOIN Bills b ON py.bill_id = b.bill_id
           JOIN Customers c ON b.customer_id = c.customer_id
           ORDER BY py.payment_id DESC""",
        fetch='all'
    )
    return jsonify(rows)

@payments_bp.route('/payments/bill/<int:bid>', methods=['GET'])
def get_bill_payments(bid):
    rows = execute_query(
        "SELECT * FROM Payments WHERE bill_id = %s ORDER BY payment_date DESC",
        (bid,), fetch='all'
    )
    return jsonify(rows)

@payments_bp.route('/payments', methods=['POST'])
def record_payment():
    data = request.get_json()
    bill_id = data['bill_id']
    execute_query(
        "INSERT INTO Payments (bill_id, paid_amount, payment_date, method, status) VALUES (%s, %s, CURRENT_DATE, %s, 'Completed')",
        (bill_id, data['paid_amount'], data['method'])
    )
    # Auto-update bill status if fully paid
    execute_query(
        """UPDATE Bills SET status = CASE
               WHEN billed_amount <= (
                   SELECT COALESCE(SUM(paid_amount), 0) FROM Payments
                   WHERE bill_id = %s AND status = 'Completed'
               ) THEN 'Paid' ELSE status END
           WHERE bill_id = %s""",
        (bill_id, bill_id)
    )
    return jsonify({'success': True, 'message': 'Payment recorded'}), 201

from flask import Blueprint, request, jsonify
from database import execute_query

technicians_bp = Blueprint('technicians', __name__)

@technicians_bp.route('/technicians', methods=['GET'])
def get_technicians():
    rows = execute_query("SELECT technician_id, technician_name, phone_number, username FROM Technicians ORDER BY technician_id", fetch='all')
    return jsonify(rows)

@technicians_bp.route('/technicians', methods=['POST'])
def add_technician():
    data = request.get_json()
    if not data.get('username') or not data.get('passwords'):
        return jsonify({'error': 'Username and password are required for technician accounts'}), 400
    execute_query(
        "INSERT INTO Users (role, username, passwords) VALUES (%s, %s, %s)",
        ('Technician', data['username'], data['passwords'])
    )
    execute_query(
        "INSERT INTO Technicians (technician_name, phone_number, username) VALUES (%s, %s, %s)",
        (data['technician_name'], data.get('phone_number'), data['username'])
    )
    return jsonify({'success': True, 'message': 'Technician added'}), 201

@technicians_bp.route('/technicians/<int:tid>', methods=['DELETE'])
def delete_technician(tid):
    execute_query("DELETE FROM Technicians WHERE technician_id = %s", (tid,))
    return jsonify({'success': True, 'message': 'Technician deleted'})

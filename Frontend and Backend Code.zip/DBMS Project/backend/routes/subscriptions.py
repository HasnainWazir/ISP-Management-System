from flask import Blueprint, request, jsonify
from database import execute_query

subscriptions_bp = Blueprint('subscriptions', __name__)

@subscriptions_bp.route('/subscriptions', methods=['GET'])
def get_subscriptions():
    rows = execute_query(
        """SELECT s.subscription_id, c.customer_name, p.internet_speed, p.price,
                  s.start_date, s.customer_id, s.package_id
           FROM Subscriptions s
           JOIN Customers c ON s.customer_id = c.customer_id
           JOIN Packages p ON s.package_id = p.package_id
           ORDER BY s.subscription_id DESC""",
        fetch='all'
    )
    return jsonify(rows)

@subscriptions_bp.route('/subscriptions/customer/<int:cid>', methods=['GET'])
def get_customer_subscriptions(cid):
    rows = execute_query(
        """SELECT s.subscription_id, c.customer_name, p.internet_speed, p.price, s.start_date
           FROM Subscriptions s
           JOIN Customers c ON s.customer_id = c.customer_id
           JOIN Packages p ON s.package_id = p.package_id
           WHERE s.customer_id = %s ORDER BY s.start_date DESC""",
        (cid,), fetch='all'
    )
    return jsonify(rows)

@subscriptions_bp.route('/subscriptions', methods=['POST'])
def create_subscription():
    data = request.get_json()
    execute_query(
        "INSERT INTO Subscriptions (customer_id, package_id, start_date) VALUES (%s, %s, CURRENT_DATE)",
        (data['customer_id'], data['package_id'])
    )
    return jsonify({'success': True, 'message': 'Subscription created'}), 201

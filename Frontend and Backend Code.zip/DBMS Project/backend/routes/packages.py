from flask import Blueprint, request, jsonify
from database import execute_query

packages_bp = Blueprint('packages', __name__)

@packages_bp.route('/packages', methods=['GET'])
def get_packages():
    rows = execute_query("SELECT * FROM Packages ORDER BY price", fetch='all')
    return jsonify(rows)

@packages_bp.route('/packages', methods=['POST'])
def add_package():
    data = request.get_json()
    execute_query(
        "INSERT INTO Packages (internet_speed, price, data_limit) VALUES (%s, %s, %s)",
        (data.get('internet_speed'), data['price'], data.get('data_limit'))
    )
    return jsonify({'success': True, 'message': 'Package added'}), 201

@packages_bp.route('/packages/<int:pid>', methods=['PUT'])
def update_package(pid):
    data = request.get_json()
    execute_query(
        "UPDATE Packages SET internet_speed=%s, price=%s, data_limit=%s WHERE package_id=%s",
        (data.get('internet_speed'), data['price'], data.get('data_limit'), pid)
    )
    return jsonify({'success': True, 'message': 'Package updated'})

@packages_bp.route('/packages/<int:pid>', methods=['DELETE'])
def delete_package(pid):
    execute_query("DELETE FROM Packages WHERE package_id = %s", (pid,))
    return jsonify({'success': True, 'message': 'Package deleted'})

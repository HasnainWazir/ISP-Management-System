from flask import Blueprint, request, jsonify
from database import execute_query

assignments_bp = Blueprint('assignments', __name__)


@assignments_bp.route('/assignments', methods=['GET'])
def get_assignments():
    rows = execute_query(
        """SELECT a.assignment_id, co.description AS complaint, co.status,
                  t.technician_name, a.assigned_date, a.complain_id, a.technician_id
           FROM Assignments a
           JOIN Complaints co ON a.complain_id = co.complain_id
           JOIN Technicians t ON a.technician_id = t.technician_id
           ORDER BY a.assignment_id DESC""",
        fetch='all'
    )
    return jsonify(rows)


@assignments_bp.route('/assignments/technician/<int:tid>', methods=['GET'])
def get_technician_assignments(tid):
    rows = execute_query(
        """SELECT a.assignment_id, co.complain_id, co.description AS complaint, co.status,
                  t.technician_name, a.assigned_date
           FROM Assignments a
           JOIN Complaints co ON a.complain_id = co.complain_id
           JOIN Technicians t ON a.technician_id = t.technician_id
           WHERE a.technician_id = %s ORDER BY a.assigned_date DESC""",
        (tid,), fetch='all'
    )
    return jsonify(rows)


@assignments_bp.route('/assignments/technician-username/<username>', methods=['GET'])
def get_technician_assignments_by_username(username):
    rows = execute_query(
        """SELECT a.assignment_id, co.complain_id, co.description AS complaint, co.status,
                  t.technician_name, a.assigned_date
           FROM Assignments a
           JOIN Complaints co ON a.complain_id = co.complain_id
           JOIN Technicians t ON a.technician_id = t.technician_id
           WHERE t.username = %s ORDER BY a.assigned_date DESC""",
        (username,), fetch='all'
    )
    return jsonify(rows)


@assignments_bp.route('/assignments', methods=['POST'])
def assign_technician():
    data = request.get_json()
    complain_id = data.get('complain_id')
    technician_id = data.get('technician_id')
    if not complain_id or not technician_id:
        return jsonify({'error': 'complain_id and technician_id are required'}), 400

    execute_query(
        """INSERT INTO Assignments (complain_id, technician_id, assigned_date)
           VALUES (%s, %s, CURRENT_DATE)""",
        (complain_id, technician_id)
    )
    execute_query(
        "UPDATE Complaints SET status = 'In Progress' WHERE complain_id = %s",
        (complain_id,)
    )
    return jsonify({'success': True, 'message': 'Technician assigned'}), 201


# ── NEW: Technician updates assignment (and syncs the linked complaint) status ──
@assignments_bp.route('/assignments/<int:aid>/status', methods=['PUT'])
def update_assignment_status(aid):
    data = request.get_json()
    new_status = data.get('status', '').strip()
    allowed = {'In Progress', 'Resolved', 'Closed'}
    if new_status not in allowed:
        return jsonify({'error': f'Status must be one of: {", ".join(allowed)}'}), 400

    # Fetch the linked complaint id before updating
    row = execute_query(
        "SELECT complain_id FROM Assignments WHERE assignment_id = %s",
        (aid,), fetch='one'
    )
    if not row:
        return jsonify({'error': 'Assignment not found'}), 404

    # Update complaint status (Assignments table has no status column)
    # Keep complaint status in sync
    execute_query(
        "UPDATE Complaints SET status = %s WHERE complain_id = %s",
        (new_status, row['complain_id'])
    )

    return jsonify({'success': True, 'message': f'Status updated to {new_status}'})

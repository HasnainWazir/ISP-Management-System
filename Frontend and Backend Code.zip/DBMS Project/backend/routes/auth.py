from flask import Blueprint, request, jsonify
from database import execute_query

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('passwords', '').strip()
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    user = execute_query(
        "SELECT user_id, role FROM Users WHERE username = %s AND passwords = %s",
        (username, password), fetch='one'
    )
    if user:
        result = {'success': True, 'user_id': user['user_id'], 'role': user['role'], 'username': username}
        
        # Get customer_id if customer
        if user['role'] == 'Customer':
            customer = execute_query(
                "SELECT customer_id FROM Customers WHERE username = %s",
                (username,), fetch='one'
            )
            if customer:
                result['customer_id'] = customer['customer_id']
        
        # Get technician_id if technician
        if user['role'] == 'Technician':
            technician = execute_query(
                "SELECT technician_id FROM Technicians WHERE username = %s",
                (username,), fetch='one'
            )
            if technician:
                result['technician_id'] = technician['technician_id']
        
        return jsonify(result)
    return jsonify({'error': 'Invalid username or password'}), 401

@auth_bp.route('/users', methods=['GET'])
def get_users():
    users = execute_query("SELECT user_id, role, username FROM Users ORDER BY user_id", fetch='all')
    return jsonify(users)

@auth_bp.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()
    execute_query(
        "INSERT INTO Users (role, username, passwords) VALUES (%s, %s, %s)",
        (data['role'], data['username'], data['passwords'])
    )
    return jsonify({'success': True, 'message': 'User created'}), 201

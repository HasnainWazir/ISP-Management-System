from flask import Blueprint, jsonify
from database import execute_query

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/reports/dashboard', methods=['GET'])
def dashboard():
    row = execute_query(
        """SELECT
            (SELECT COUNT(*) FROM Customers) AS total_customers,
            (SELECT COUNT(*) FROM Subscriptions) AS total_subscriptions,
            (SELECT COUNT(*) FROM Technicians) AS total_technicians,
            (SELECT COALESCE(SUM(paid_amount),0) FROM Payments WHERE status='Completed') AS total_revenue,
            (SELECT COUNT(*) FROM Bills WHERE status='Unpaid') AS unpaid_bills,
            (SELECT COUNT(*) FROM Bills WHERE status='Overdue') AS overdue_bills,
            (SELECT COUNT(*) FROM Complaints WHERE status='Open') AS open_complaints,
            (SELECT COUNT(*) FROM Complaints WHERE status='In Progress') AS inprogress_complaints,
            (SELECT COUNT(*) FROM Complaints WHERE status='Resolved') AS resolved_complaints""",
        fetch='one'
    )
    return jsonify(row)

@reports_bp.route('/reports/revenue', methods=['GET'])
def revenue():
    total = execute_query(
        "SELECT COALESCE(SUM(paid_amount),0) AS total_revenue FROM Payments WHERE status='Completed'",
        fetch='one'
    )
    monthly = execute_query(
        """SELECT TO_CHAR(payment_date,'Month') AS month,
                  EXTRACT(YEAR FROM payment_date) AS year,
                  SUM(paid_amount) AS monthly_revenue,
                  COUNT(payment_id) AS total_transactions
           FROM Payments WHERE status='Completed'
           GROUP BY EXTRACT(YEAR FROM payment_date), EXTRACT(MONTH FROM payment_date),
                    TO_CHAR(payment_date,'Month')
           ORDER BY year, EXTRACT(MONTH FROM payment_date)""",
        fetch='all'
    )
    by_method = execute_query(
        """SELECT method, COUNT(payment_id) AS total_payments, SUM(paid_amount) AS total_collected
           FROM Payments WHERE status='Completed'
           GROUP BY method ORDER BY total_collected DESC""",
        fetch='all'
    )
    efficiency = execute_query(
        """SELECT SUM(b.billed_amount) AS total_billed,
                  COALESCE(SUM(p.paid_amount),0) AS total_collected,
                  SUM(b.billed_amount) - COALESCE(SUM(p.paid_amount),0) AS outstanding_amount,
                  ROUND(COALESCE(SUM(p.paid_amount),0) / NULLIF(SUM(b.billed_amount),0)*100, 2) AS collection_percentage
           FROM Bills b LEFT JOIN Payments p ON b.bill_id=p.bill_id AND p.status='Completed'""",
        fetch='one'
    )
    return jsonify({'total': total, 'monthly': monthly, 'by_method': by_method, 'efficiency': efficiency})

@reports_bp.route('/reports/unpaid-bills', methods=['GET'])
def unpaid_bills():
    rows = execute_query(
        """SELECT COUNT(bill_id) AS unpaid_bills, SUM(billed_amount) AS total_unpaid_amount
           FROM Bills WHERE status='Unpaid'""",
        fetch='one'
    )
    customers_unpaid = execute_query(
        """SELECT customer_id, customer_name, phone_number FROM Customers
           WHERE customer_id IN (SELECT DISTINCT customer_id FROM Bills WHERE status='Unpaid')""",
        fetch='all'
    )
    return jsonify({'summary': rows, 'customers': customers_unpaid})

@reports_bp.route('/reports/complaints-summary', methods=['GET'])
def complaints_summary():
    breakdown = execute_query(
        """SELECT status, COUNT(complain_id) AS total,
                  ROUND(COUNT(complain_id)*100.0/NULLIF((SELECT COUNT(*) FROM Complaints),0),2) AS percentage
           FROM Complaints GROUP BY status ORDER BY total DESC""",
        fetch='all'
    )
    per_technician = execute_query(
        """SELECT t.technician_name, COUNT(a.assignment_id) AS total_complaints_handled
           FROM Technicians t LEFT JOIN Assignments a ON t.technician_id=a.technician_id
           GROUP BY t.technician_id, t.technician_name ORDER BY total_complaints_handled DESC""",
        fetch='all'
    )
    return jsonify({'breakdown': breakdown, 'per_technician': per_technician})

@reports_bp.route('/reports/customers-per-area', methods=['GET'])
def customers_per_area():
    rows = execute_query(
        """SELECT a.area_name, COUNT(c.customer_id) AS total_customers
           FROM Areas a LEFT JOIN Customers c ON a.area_id=c.area_id
           GROUP BY a.area_name ORDER BY total_customers DESC""",
        fetch='all'
    )
    most_active = execute_query(
        """SELECT a.area_name, COUNT(c.customer_id) AS total_customers
           FROM Areas a JOIN Customers c ON a.area_id=c.area_id
           GROUP BY a.area_id, a.area_name ORDER BY total_customers DESC LIMIT 1""",
        fetch='one'
    )
    return jsonify({'distribution': rows, 'most_active': most_active})

@reports_bp.route('/reports/packages', methods=['GET'])
def packages_report():
    most_used = execute_query(
        """SELECT p.package_id, p.internet_speed, p.price, COUNT(s.subscription_id) AS total_subscriptions
           FROM Packages p JOIN Subscriptions s ON p.package_id=s.package_id
           GROUP BY p.package_id, p.internet_speed, p.price
           ORDER BY total_subscriptions DESC LIMIT 1""",
        fetch='one'
    )
    never_subscribed = execute_query(
        """SELECT package_id, internet_speed, price FROM Packages
           WHERE package_id NOT IN (SELECT DISTINCT package_id FROM Subscriptions)""",
        fetch='all'
    )
    return jsonify({'most_used': most_used, 'never_subscribed': never_subscribed})

@reports_bp.route('/reports/bills-summary', methods=['GET'])
def bills_summary():
    rows = execute_query(
        """SELECT c.customer_id, c.customer_name,
                  COUNT(b.bill_id) AS total_bills,
                  COALESCE(SUM(b.billed_amount),0) AS total_billed,
                  SUM(CASE WHEN b.status='Paid' THEN b.billed_amount ELSE 0 END) AS total_paid_bills,
                  SUM(CASE WHEN b.status='Unpaid' THEN b.billed_amount ELSE 0 END) AS total_unpaid_bills
           FROM Customers c LEFT JOIN Bills b ON c.customer_id=b.customer_id
           GROUP BY c.customer_id, c.customer_name ORDER BY total_billed DESC""",
        fetch='all'
    )
    return jsonify(rows)

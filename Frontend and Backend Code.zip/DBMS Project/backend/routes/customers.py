from flask import Blueprint, request, jsonify
from database import execute_query

customers_bp = Blueprint('customers', __name__)

@customers_bp.route('/customers', methods=['GET'])
def get_customers():
    search = request.args.get('search', '')
    if search:
        rows = execute_query(
            """SELECT c.customer_id, c.customer_name, c.phone_number, c.address, a.area_name, c.username
               FROM Customers c LEFT JOIN Areas a ON c.area_id = a.area_id
               WHERE c.customer_name ILIKE %s ORDER BY c.customer_id""",
            (f'%{search}%',), fetch='all'
        )
    else:
        rows = execute_query(
            """SELECT c.customer_id, c.customer_name, c.phone_number, c.address, a.area_name, c.area_id, c.username
               FROM Customers c LEFT JOIN Areas a ON c.area_id = a.area_id
               ORDER BY c.customer_id""",
            fetch='all'
        )
    return jsonify(rows)

@customers_bp.route('/customers/<int:cid>', methods=['GET'])
def get_customer(cid):
    row = execute_query(
        """SELECT c.customer_id, c.customer_name, c.phone_number, c.address, a.area_name, c.area_id, c.username
           FROM Customers c JOIN Areas a ON c.area_id = a.area_id
           WHERE c.customer_id = %s""",
        (cid,), fetch='one'
    )
    if not row:
        return jsonify({'error': 'Customer not found'}), 404
    return jsonify(row)

@customers_bp.route('/customers', methods=['POST'])
def add_customer():
    data = request.get_json()
    if not data.get('username') or not data.get('passwords'):
        return jsonify({'error': 'Username and password are required for customer accounts'}), 400
    execute_query(
        "INSERT INTO Users (role, username, passwords) VALUES (%s, %s, %s)",
        ('Customer', data['username'], data['passwords'])
    )
    execute_query(
        "INSERT INTO Customers (customer_name, phone_number, address, area_id, username) VALUES (%s, %s, %s, %s, %s)",
        (data['customer_name'], data.get('phone_number'), data.get('address'), data.get('area_id'), data['username'])
    )
    return jsonify({'success': True, 'message': 'Customer added'}), 201

@customers_bp.route('/customers/<int:cid>', methods=['PUT'])
def update_customer(cid):
    data = request.get_json()
    username  = data.get('username', '').strip()
    passwords = data.get('passwords', '').strip()

    # Always update basic customer info
    execute_query(
        "UPDATE Customers SET customer_name=%s, phone_number=%s, address=%s, area_id=%s WHERE customer_id=%s",
        (data['customer_name'], data.get('phone_number'), data.get('address'), data.get('area_id'), cid)
    )

    # If admin provided credentials, upsert the Users table and link username
    if username and passwords:
        # Upsert: create user if not exists, update password if exists
        execute_query(
            """INSERT INTO Users (role, username, passwords)
               VALUES ('Customer', %s, %s)
               ON CONFLICT (username) DO UPDATE SET passwords = EXCLUDED.passwords""",
            (username, passwords)
        )
        # Link the username to the customer record
        execute_query(
            "UPDATE Customers SET username=%s WHERE customer_id=%s",
            (username, cid)
        )

    return jsonify({'success': True, 'message': 'Customer updated'})

@customers_bp.route('/customers/<int:cid>', methods=['DELETE'])
def delete_customer(cid):
    execute_query("DELETE FROM Customers WHERE customer_id = %s", (cid,))
    return jsonify({'success': True, 'message': 'Customer deleted'})

# --- Areas ---
@customers_bp.route('/areas', methods=['GET'])
def get_areas():
    rows = execute_query("SELECT * FROM Areas ORDER BY area_name", fetch='all')
    return jsonify(rows)

@customers_bp.route('/areas', methods=['POST'])
def add_area():
    data = request.get_json()
    execute_query("INSERT INTO Areas (area_name) VALUES (%s)", (data['area_name'],))
    return jsonify({'success': True, 'message': 'Area added'}), 201

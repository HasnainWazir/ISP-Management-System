from flask import Blueprint, request, jsonify
from database import execute_query

complaints_bp = Blueprint('complaints', __name__)


@complaints_bp.route('/complaints', methods=['GET'])
def get_complaints():
    rows = execute_query(
        """SELECT co.complain_id, c.customer_name, co.description, co.status,
                  t.technician_name, a.assigned_date, co.customer_id
           FROM Complaints co
           JOIN Customers c ON co.customer_id = c.customer_id
           LEFT JOIN Assignments a ON co.complain_id = a.complain_id
           LEFT JOIN Technicians t ON a.technician_id = t.technician_id
           ORDER BY CASE co.status
               WHEN 'Open' THEN 1 WHEN 'In Progress' THEN 2
               WHEN 'Resolved' THEN 3 WHEN 'Closed' THEN 4 END,
           co.complain_id DESC""",
        fetch='all'
    )
    return jsonify(rows)


# ── NEW: Returns only complaints assigned to a specific technician (by username) ──
@complaints_bp.route('/complaints/technician/<username>', methods=['GET'])
def get_technician_complaints(username):
    rows = execute_query(
        """SELECT co.complain_id, c.customer_name, co.description, co.status,
                  t.technician_name, a.assigned_date, a.assignment_id
           FROM Complaints co
           JOIN Customers c ON co.customer_id = c.customer_id
           JOIN Assignments a ON co.complain_id = a.complain_id
           JOIN Technicians t ON a.technician_id = t.technician_id
           WHERE t.username = %s
           ORDER BY CASE co.status
               WHEN 'Open' THEN 1 WHEN 'In Progress' THEN 2
               WHEN 'Resolved' THEN 3 WHEN 'Closed' THEN 4 END,
           co.complain_id DESC""",
        (username,), fetch='all'
    )
    return jsonify(rows)


@complaints_bp.route('/complaints/customer/<int:cid>', methods=['GET'])
def get_customer_complaints(cid):
    rows = execute_query(
        """SELECT co.complain_id, c.customer_name, co.description, co.status,
                  t.technician_name, a.assigned_date
           FROM Complaints co
           JOIN Customers c ON co.customer_id = c.customer_id
           LEFT JOIN Assignments a ON co.complain_id = a.complain_id
           LEFT JOIN Technicians t ON a.technician_id = t.technician_id
           WHERE co.customer_id = %s
           ORDER BY CASE co.status
               WHEN 'Open' THEN 1 WHEN 'In Progress' THEN 2
               WHEN 'Resolved' THEN 3 WHEN 'Closed' THEN 4 END,
           co.complain_id DESC""",
        (cid,), fetch='all'
    )
    return jsonify(rows)


@complaints_bp.route('/complaints', methods=['POST'])
def add_complaint():
    data = request.get_json()
    if not data.get('customer_id') or not data.get('description'):
        return jsonify({'error': 'customer_id and description are required'}), 400
    execute_query(
        "INSERT INTO Complaints (customer_id, description, status) VALUES (%s, %s, 'Open')",
        (data['customer_id'], data['description'])
    )
    return jsonify({'success': True, 'message': 'Complaint registered'}), 201


@complaints_bp.route('/complaints/<int:cid>', methods=['PUT'])
def update_complaint(cid):
    data = request.get_json()
    new_status = data.get('status', '').strip()
    allowed = {'Open', 'In Progress', 'Resolved', 'Closed'}
    if new_status not in allowed:
        return jsonify({'error': f'Status must be one of: {", ".join(allowed)}'}), 400
    execute_query(
        "UPDATE Complaints SET status = %s WHERE complain_id = %s",
        (new_status, cid)
    )
    return jsonify({'success': True, 'message': 'Complaint updated'})


@complaints_bp.route('/complaints/close-resolved', methods=['POST'])
def close_resolved():
    execute_query("UPDATE Complaints SET status = 'Closed' WHERE status = 'Resolved'")
    return jsonify({'success': True, 'message': 'Resolved complaints closed'})

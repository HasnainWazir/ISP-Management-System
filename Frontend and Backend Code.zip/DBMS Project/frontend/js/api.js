const API_BASE = 'http://localhost:5000';

// ── Auth helpers ──
function getUser() {
    try { return JSON.parse(sessionStorage.getItem('isp_user')) || null; }
    catch { return null; }
}

function requireAuth(allowedRoles = []) {
    const user = getUser();
    if (!user) { window.location.href = 'index.html'; return null; }
    if (allowedRoles.length && !allowedRoles.includes(user.role)) {
        alert('Access denied for your role.');
        window.history.back();
        return null;
    }
    return user;
}

function logout() {
    sessionStorage.removeItem('isp_user');
    window.location.href = 'index.html';
}

// ── API fetch wrapper ──
async function api(path, options = {}) {
    // Guard: catch undefined IDs in URL (e.g. /customer/undefined)
    if (path.includes('/undefined') || path.includes('/null')) {
        throw new Error('Session error: please log out and log back in.');
    }
    const res = await fetch(API_BASE + path, {
        headers: { 'Content-Type': 'application/json', ...options.headers },
        ...options
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
}

// ── Toast notifications ──
function toast(msg, type = 'success') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = `show ${type}`;
    setTimeout(() => el.className = '', 2800);
}

// ── Modal helpers ──
function openModal(id) {
    document.getElementById(id).classList.add('open');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}

// ── Confirm dialog (replaces broken confirm() in file:// context) ──
function confirmDialog(msg) {
    return new Promise(resolve => {
        // Inject the modal once
        let overlay = document.getElementById('_confirm-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = '_confirm-overlay';
            overlay.style.cssText = `
                display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);
                z-index:9999;align-items:center;justify-content:center;
            `;
            overlay.innerHTML = `
                <div style="background:#1e2a3a;border:1px solid #2d3a4a;border-radius:12px;
                            padding:28px 32px;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.5)">
                    <p id="_confirm-msg" style="color:#e2e8f0;font-size:1rem;line-height:1.6;margin:0 0 22px"></p>
                    <div style="display:flex;gap:10px;justify-content:flex-end">
                        <button id="_confirm-no"  class="btn btn-ghost">Cancel</button>
                        <button id="_confirm-yes" class="btn btn-primary">Confirm</button>
                    </div>
                </div>`;
            document.body.appendChild(overlay);
        }
        document.getElementById('_confirm-msg').textContent = msg;
        overlay.style.display = 'flex';

        function cleanup(result) {
            overlay.style.display = 'none';
            resolve(result);
        }
        document.getElementById('_confirm-yes').onclick = () => cleanup(true);
        document.getElementById('_confirm-no').onclick  = () => cleanup(false);
        overlay.onclick = e => { if (e.target === overlay) cleanup(false); };
    });
}

// ── Sidebar active link ──
function setActiveLink() {
    const page = window.location.pathname.split('/').pop();
    document.querySelectorAll('.sidebar-nav a').forEach(a => {
        a.classList.toggle('active', a.getAttribute('href') === page);
    });
}

// ── Render user in sidebar ──
function renderSidebarUser() {
    const user = getUser();
    const el = document.getElementById('sidebar-user');
    if (el && user) {
        el.innerHTML = `
            <div style="font-weight:600;color:#fff;font-size:.88rem">${user.username}</div>
            <div style="font-size:.77rem;margin-top:2px">${user.role}</div>
            <a href="#" onclick="logout()" style="margin-top:8px;display:inline-block">Logout</a>
        `;
    }
}

// ── Sidebar HTML (included by all pages) ──
function renderSidebar(activePage) {
    const user = getUser();
    const role = user ? user.role : null;

    let links = [
        { href: 'dashboard.html', icon: '📊', label: 'Dashboard' },
        { href: 'customers.html', icon: '👥', label: 'Customers' },
        { href: 'packages.html',  icon: '📦', label: 'Packages' },
        { href: 'subscriptions.html', icon: '🔗', label: 'Subscriptions' },
        { href: 'bills.html',     icon: '💰', label: 'Billing' },
        { href: 'payments.html',  icon: '💳', label: 'Payments' },
        { href: 'complaints.html',icon: '🛠️', label: 'Complaints' },
        { href: 'technicians.html',icon:'👨‍🔧', label: 'Technicians' },
        { href: 'reports.html',   icon: '📈', label: 'Reports' },
    ];

    if (role === 'Technician') {
        links = links.filter(l => ['dashboard.html', 'assignments.html', 'complaints.html'].includes(l.href));
    } else if (role === 'Customer') {
        links = links.filter(l => ['dashboard.html', 'subscriptions.html', 'bills.html', 'complaints.html'].includes(l.href));
    }

    const nav = links.map(l =>
        `<a href="${l.href}" class="${l.href === activePage ? 'active' : ''}">
            <span class="icon">${l.icon}</span>${l.label}
        </a>`
    ).join('');

    document.getElementById('sidebar-placeholder').innerHTML = `
        <div class="sidebar">
            <div class="sidebar-logo"><span>🌐</span> ISP Manager</div>
            <nav class="sidebar-nav">${nav}</nav>
            <div class="sidebar-footer" id="sidebar-user"></div>
        </div>
    `;
    renderSidebarUser();
}

// ── Format helpers ──
function fmt(val, type = 'text') {
    if (val === null || val === undefined) return '—';
    if (type === 'currency') return 'PKR ' + Number(val).toLocaleString();
    if (type === 'date') return new Date(val).toLocaleDateString('en-PK');
    return val;
}

function statusBadge(status) {
    const map = {
        'Paid': 'badge-paid', 'Unpaid': 'badge-unpaid', 'Overdue': 'badge-overdue',
        'Open': 'badge-open', 'In Progress': 'badge-progress',
        'Resolved': 'badge-resolved', 'Closed': 'badge-closed',
        'Completed': 'badge-paid', 'Pending': 'badge-unpaid', 'Failed': 'badge-overdue',
        'Admin': 'badge-admin', 'Staff': 'badge-staff',
        'Technician': 'badge-tech', 'Customer': 'badge-customer'
    };
    return `<span class="badge ${map[status] || ''}">${status || '—'}</span>`;
}

import sqlite3

conn = sqlite3.connect('isp.db')
with open('Table_Creation.sql', 'r') as f:
    sql = f.read()
conn.executescript(sql)
conn.commit()
conn.close()
print('Database initialized')